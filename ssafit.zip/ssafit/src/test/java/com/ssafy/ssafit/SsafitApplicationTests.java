package com.ssafy.ssafit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsafitApplicationTests {

	@Test
	void contextLoads() {
	}

}
