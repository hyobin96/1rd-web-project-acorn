package com.ssafy.ssafit.model.exception;

public class PlaylistNotSelectedException extends RuntimeException {
	public PlaylistNotSelectedException(String message) {
		super(message);
	}
}
