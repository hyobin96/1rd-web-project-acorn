package com.ssafy.ssafit.model.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ssafit.model.dao.PlayListDao;
import com.ssafy.ssafit.model.dto.PlayList;
import com.ssafy.ssafit.model.exception.PlayListNotDeletedException;
import com.ssafy.ssafit.model.exception.PlayListNotInsertedException;
import com.ssafy.ssafit.model.exception.PlayListNotSelectedException;

@Service
public class PlayListServiceImpl implements PlayListService {
	@Autowired
	private PlayListDao playListDao;
	
	@Override
	public void deletePlayListById(int id) {
		if(playListDao.deletePlayListById(id) == 1) {
			throw new PlayListNotDeletedException("playlist가 삭제되지 않았습니다.");
		}
	}

	@Override
	public void createPlayList(PlayList playList) {
		if(playListDao.insertPlayList(playList) == 1) {
			throw new PlayListNotInsertedException("playlist가 생성되지 않았습니다.");
		}
	}

	@Override
	public PlayList getPlayList(int id) {
		Optional<PlayList> playList = playListDao.selectPlayList(id);
		if(playList.isEmpty()) {
			throw new PlayListNotSelectedException("playlist가 선택되지 않았습니다.");
		}
		return playList.get();
	}

}
