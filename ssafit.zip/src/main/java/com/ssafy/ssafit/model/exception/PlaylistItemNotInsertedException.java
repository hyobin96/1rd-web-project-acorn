package com.ssafy.ssafit.model.exception;

public class PlaylistItemNotInsertedException extends RuntimeException {
	public PlaylistItemNotInsertedException(String message) {
		super(message);
	}
}
