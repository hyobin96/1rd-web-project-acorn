package com.ssafy.ssafit.model.exception;

public class PlayListNotSelectedException extends RuntimeException {
	public PlayListNotSelectedException(String message) {
		super(message);
	}
}
