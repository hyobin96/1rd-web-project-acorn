package com.ssafy.ssafit.model.exception;

public class PlaylistNotInsertedException extends RuntimeException {
	public PlaylistNotInsertedException(String message) {
		super(message);
	}
}
