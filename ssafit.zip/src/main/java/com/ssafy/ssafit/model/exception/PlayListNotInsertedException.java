package com.ssafy.ssafit.model.exception;

public class PlayListNotInsertedException extends RuntimeException {
	public PlayListNotInsertedException(String message) {
		super(message);
	}
}
