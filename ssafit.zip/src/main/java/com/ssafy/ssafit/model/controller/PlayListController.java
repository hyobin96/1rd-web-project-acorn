package com.ssafy.ssafit.model.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.ssafit.model.dto.PlayList;
import com.ssafy.ssafit.model.service.PlayListService;

@RestController
@RequestMapping("/api/playlist")
@CrossOrigin("*")
public class PlayListController {
	@Autowired
	private PlayListService playListService;
	
	@GetMapping("{userId}")
	public ResponseEntity<PlayList> readPlayList(@PathVariable("userId") int userId){
		return ResponseEntity.ok(playListService.getPlayList(userId));
	}
}
