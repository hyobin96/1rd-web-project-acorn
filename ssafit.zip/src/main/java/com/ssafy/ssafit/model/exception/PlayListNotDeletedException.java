package com.ssafy.ssafit.model.exception;

public class PlayListNotDeletedException extends RuntimeException {
	public PlayListNotDeletedException(String message) {
        super(message);
    }
}
