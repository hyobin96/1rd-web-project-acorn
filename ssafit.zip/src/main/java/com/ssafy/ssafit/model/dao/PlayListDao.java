package com.ssafy.ssafit.model.dao;

import java.util.Optional;

import com.ssafy.ssafit.model.dto.PlayList;

public interface PlayListDao {
	/**
	 * id를 받아서 해당하는 playlist를 delete
	 * @param id
	 * @return 변경된 행의 개수
	 */
	int deletePlayListById(int id);
	
	/**
	 * playList를 playlists에 삽입
	 * @param playList
	 * @return 변경된 행의 개수
	 */
	int insertPlayList(PlayList playList);
	
	/**
	 * id를 받아서 해당하는 playlist를 선택해서 dto에 담아서 반환
	 * @param id
	 * @return PlayList가 들어간 Optional 객체를 반환
	 */
	Optional<PlayList> selectPlayList(int id);
}
