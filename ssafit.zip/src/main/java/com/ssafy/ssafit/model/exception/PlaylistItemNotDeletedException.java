package com.ssafy.ssafit.model.exception;

public class PlaylistItemNotDeletedException extends RuntimeException {
	public PlaylistItemNotDeletedException(String message) {
		super(message);
	}
}
