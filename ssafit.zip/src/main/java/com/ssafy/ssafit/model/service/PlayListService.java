package com.ssafy.ssafit.model.service;

import com.ssafy.ssafit.model.dto.PlayList;

public interface PlayListService {
	
	/**
	 * playlists에서 id가 일치하는 playlist를 db에서 삭제한다.
	 * 삭제가 되지 않는다면 에러를 던진다.
	 * @param id
	 */
	void deletePlayListById(int id);
	
	/**
	 * 새로운 playlist를 만든다
	 * 생성되지 않는다면 에러를 발생한다
	 * @param playList
	 */
	void createPlayList(PlayList playList);
	
	/**
	 * id가 일치하는 playlist를 가져온다.
	 * 일치하는 playlist가 없다면 에러를 발생한다.
	 * @param id
	 */
	PlayList getPlayList(int id);
	
}
